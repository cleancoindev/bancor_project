export const prettifyNumber = (): string => {
  return "";
};
