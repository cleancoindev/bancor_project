import { faClock } from "@fortawesome/pro-regular-svg-icons/faClock";

export const far = [faClock];
