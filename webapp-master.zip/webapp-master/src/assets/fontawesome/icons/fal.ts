import { faTimes } from "@fortawesome/pro-light-svg-icons/faTimes";
import { faLanguage } from "@fortawesome/pro-light-svg-icons/faLanguage";
import { faGlobe } from "@fortawesome/pro-light-svg-icons/faGlobe";

export const fal = [faTimes, faLanguage, faGlobe];
