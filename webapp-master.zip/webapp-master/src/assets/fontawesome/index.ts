import { fas } from "./icons/fas";
import { fal } from "./icons/fal";
import { fab } from "./icons/fab";
import { far } from "./icons/far";

export { fas, fal, fab, far };
